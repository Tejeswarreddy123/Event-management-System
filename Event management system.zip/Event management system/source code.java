import java.util.*;
import java.text.SimpleDateFormat;

class Event {
    private String name;
    private Date date;
    private int capacity;
    private List<Ticket> tickets;
    public List<Ticket> getRegisteredTickets() {
        return tickets;
    }

    public Event(String name, Date date, int capacity) {
        this.name = name;
        this.date = date;
        this.capacity = capacity;
        this.tickets = new ArrayList<>();
    }

    public String getName() { return name; }
    public Date getDate() { return date; }
    public int getCapacity() { return capacity; }
    public List<Ticket> getTickets() { return tickets; }

    public boolean addTicket(Ticket ticket) {
        if (tickets.size() < capacity) {
            tickets.add(ticket);
            return true;
        }
        return false;
    }

    public int getAvailableTickets() {
        return capacity - tickets.size();
    }

    @Override
    public String toString() {
        return name + " on " + new SimpleDateFormat("yyyy-MM-dd").format(date) + " - " + getAvailableTickets() + " tickets available.";
    }
}

abstract class Ticket {
    private String ticketId;
    private String attendeeName;

    public Ticket(String ticketId, String attendeeName) {
        this.ticketId = ticketId;
        this.attendeeName = attendeeName;
    }

    public String getTicketId() { return ticketId; }
    public String getAttendeeName() { return attendeeName; }
    public abstract double getPrice();

    public String getDetails() {
        return "Ticket ID: " + ticketId + "\nAttendee Name: " + attendeeName + "\nPrice: $" + getPrice();
    }
}

class VIPTicket extends Ticket {
    private static final double DEFAULT_PRICE_INR = 500.0; // VIP ticket price in INR

    public VIPTicket(String ticketId, String attendeeName) {
        super(ticketId, attendeeName);
    }

    @Override
    public double getPrice() {
        return DEFAULT_PRICE_INR;
    }
}

class MiddleTicket extends Ticket {
    private static final double DEFAULT_PRICE_INR = 300.0 ; // Middle ticket price in INR

    public MiddleTicket(String ticketId, String attendeeName) {
        super(ticketId, attendeeName);
    }

    @Override
    public double getPrice() {
        return DEFAULT_PRICE_INR;
    }
}

class LowerTicket extends Ticket {
    private static final double DEFAULT_PRICE_INR = 200.0 ; // Lower ticket price in INR

    public LowerTicket(String ticketId, String attendeeName) {
        super(ticketId, attendeeName);
    }

    @Override
    public double getPrice() {
        return DEFAULT_PRICE_INR;
    }
}

class Attendee {
    private String name;

    public Attendee(String name) {
        this.name = name;
    }

    public String getName() { return name; }
}

class Payment {
    public static boolean processPayment(double amount) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select Payment Method:");
        System.out.println("1. Credit Card");
        System.out.println("2. Debit Card");
        System.out.println("3. Cash");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
            case 2:
                System.out.println("Processing card payment...");
                break;
            case 3:
                System.out.println("Pay with cash upon delivery.");
                break;
            default:
                System.out.println("Invalid choice. Defaulting to cash payment.");
        }
        System.out.println("Payment of $" + amount + " completed.");
        return true;
    }
}

class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

class UserManager {
    private Map<String, User> users = new HashMap<>();

    public boolean register(String username, String password) {
        if (users.containsKey(username)) {
            System.out.println("Username already exists. Please choose another.");
            return false;
        }
        users.put(username, new User(username, password));
        System.out.println("User registered successfully!");
        return true;
    }

    public User login(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("Login successful!");
            return user;
        }
        System.out.println("Invalid username or password.");
        return null;
    }
}

class EventManager {
    private List<Event> events = new ArrayList<>();
    private Map<String, Attendee> attendees = new HashMap<>();

    // Load default events
    public void loadDefaultEvents() {
        try {
            events.add(new Event("Holi Event", new SimpleDateFormat("yyyy-MM-dd").parse("2024-12-01"), 100));
            events.add(new Event("Music Event", new SimpleDateFormat("yyyy-MM-dd").parse("2024-11-15"), 100));
            events.add(new Event("Tech Conference", new SimpleDateFormat("yyyy-MM-dd").parse("2024-10-10"), 100));
            events.add(new Event("Games Conference", new SimpleDateFormat("yyyy-MM-dd").parse("2024-08-10"), 100));
            events.add(new Event("Food Event", new SimpleDateFormat("yyyy-MM-dd").parse("2024-10-10"), 100));
        } catch (Exception e) {
            System.out.println("Error loading default events: " + e.getMessage());
        }
    }

    private String generateTicketId() {
        StringBuilder ticketId = new StringBuilder();
        Random random = new Random();

        // Generate the first 4 letters (A-Z)
        for (int i = 0; i < 4; i++) {
            char letter = (char) ('A' + random.nextInt(26)); // Random letter from A-Z
            ticketId.append(letter);
        }

        // Generate the remaining 8 digits (0-9)
        for (int i = 0; i < 8; i++) {
            int digit = random.nextInt(10); // Random digit from 0-9
            ticketId.append(digit);
        }

        return ticketId.toString();
    }
    public void displayRegisteredTickets(String eventName) {
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(eventName)) {
                System.out.println("Registered Tickets for " + eventName + ":");
                List<Ticket> tickets = event.getRegisteredTickets();
                if (tickets.isEmpty()) {
                    System.out.println("No tickets registered for this event.");
                } else {
                    for (Ticket ticket : tickets) {
                        System.out.println(ticket.getDetails());
                    }
                }
                return;
            }
        }
        System.out.println("Event not found: " + eventName);
    }

    public void registerAttendee(String eventName, String attendeeName, String ticketType) {
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(eventName)) {
                if (event.getAvailableTickets() > 0) {
                    Ticket ticket;
                    String ticketId = generateTicketId(); // Use the new method

                    switch (ticketType.toLowerCase()) {
                        case "vip":
                            ticket = new VIPTicket(ticketId, attendeeName);
                            break;
                        case "middle":
                            ticket = new MiddleTicket(ticketId, attendeeName);
                            break;
                        case "lower":
                            ticket = new LowerTicket(ticketId, attendeeName);
                            break;
                        default:
                            System.out.println("Invalid ticket type selected.");
                            return;
                    }

                    if (Payment.processPayment(ticket.getPrice()) && event.addTicket(ticket)) {
                        attendees.put(attendeeName, new Attendee(attendeeName));
                        System.out.println("Registration successful for " + attendeeName);
                        System.out.println("Ticket Details:\n" + ticket.getDetails());
                        return;
                    }
                }
            }
        }
        System.out.println("Registration failed for " + attendeeName + ". Event may be full or does not exist.");
    }

    public void report() {
        System.out.println("Event Report:");
        for (Event event : events) {
            System.out.println(event);
        }
    }

    public void socialMediaShare(String eventName) {
        System.out.println("Sharing event \"" + eventName + "\" on social media...");
        System.out.println("Event shared successfully!");
    }
}
public class EventManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EventManager eventManager = new EventManager();
        UserManager userManager = new UserManager();
        User loggedInUser = null;

        eventManager.loadDefaultEvents(); // Load default events

        while (true) {
            if (loggedInUser == null) {
                System.out.println("1. Signup\n2. Login\n3. Exit");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Enter username: ");
                        String username = scanner.nextLine();
                        System.out.print("Enter password: ");
                        String password = scanner.nextLine();
                        userManager.register(username, password);
                        break;
                    case 2:
                        System.out.print("Enter username: ");
                        username = scanner.nextLine();
                        System.out.print("Enter password: ");
                        password = scanner.nextLine();
                        loggedInUser = userManager.login(username, password);
                        if (loggedInUser != null) {
                            // Show default events after successful login
                            System.out.println("Welcome, " + loggedInUser.getUsername() + "!");
                            eventManager.report(); // Display default events
                        }
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("1. Register Attendee\n2. Report\n3. Share Event on Social Media\n4. View Registered Tickets\n5. Logout");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Enter event name to register: ");
                        String eventName = scanner.nextLine();
                        System.out.print("Enter attendee name: ");
                        String attendeeName = scanner.nextLine();
                        System.out.print("Enter ticket type (VIP, Middle, Lower): ");
                        String ticketType = scanner.nextLine();
                        eventManager.registerAttendee(eventName, attendeeName, ticketType);
                        break;
                    case 2:
                        eventManager.report(); // Show events again
                        break;
                    case 3:
                        System.out.print("Enter event name to share: ");
                        String shareEventName = scanner.nextLine();
                        eventManager.socialMediaShare(shareEventName);
                        break;
                    case 4:
                        System.out.print("Enter event name to view registered tickets: ");
                        String viewEventName = scanner.nextLine();
                        eventManager.displayRegisteredTickets(viewEventName);
                        break;
                    case 5:
                        loggedInUser = null; // Logout
                        System.out.println("Logged out successfully.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }
    }
}